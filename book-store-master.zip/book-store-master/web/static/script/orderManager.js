window.onload=function (){
    var vue = new Vue({
        el:"#order_div",
        data:{
            orderList:{}
        },
        methods:{
            getOrder:function (){
                axios({
                    method:"POST",
                    url:"manager.do",
                    params:{
                        operate:'orderIndex'
                    }
                })
                    .then(function (value){
                        var orderList = value.data;
                        vue.orderList = orderList;
                    })
                    .catch(function (reason){ });
            },
            deliver:function (id){
                axios({
                    method:"POST",
                    url:"manager.do",
                    params:{
                        operate:'changeStatus',
                        orderNo:id
                    }
                })
                    .then(function (){
                        alert('发货成功');
                        location.reload()


                    })
                    .catch(function (reason){ });
            },
            detailMess:function (id){
                axios({
                    method:"POST",
                    url:"order.do",
                    params:{
                        operate:'detailMess',
                        id:id
                    }
                })
                    .then(function (result){

                        var orderItemList = result.data.orderItemList;
                        var str = "";
                        for (var i = 0 ; i < orderItemList.length; i++){
                            str += orderItemList[i].book.bookName + "x" + orderItemList[i].buyCount + "   ";
                        }
                        alert(str);
                    })
                    .catch(function (reason){ });
            }


        },
        mounted:function (){
            this.getOrder();
        }

    });
}