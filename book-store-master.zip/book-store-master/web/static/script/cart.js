window.onload=function (){
    var vue = new Vue({
        el:"#cart_div",
        data:{
            cart:{}
        },
        methods:{
            getCart:function (){
                axios({
                    method:"POST",
                    url:"cart.do",
                    params:{
                        operate:'cartInfo'
                    }
                })
                    .then(function (value){
                        var cart = value.data;
                        vue.cart = cart;
                    })
                    .catch(function (reason){ });
            },
            editCart:function(cartItemId,buyCount,bookId){
                axios({
                    method:"POST",
                    url:"cart.do",
                    params:{
                        operate:'editCart',
                        cartItemId:cartItemId,
                        buyCount:buyCount,
                        bookId:bookId
                    }
                })
                    .then(function (value){
                        var mess = value.data;
                        if (mess == "库存不足"){
                            alert(mess + '!');
                            vue.getCart();
                        }else {
                            vue.getCart();
                        }
                    })
                    .catch(function (reason){ });
            },
            delCart:function (cartItemId){
                axios({
                    method:"POST",
                    url:"cart.do",
                    params:{
                        operate:'delCart',
                        cartItemId:cartItemId
                    }
                })
                    .then(function (value){
                        vue.getCart();
                    })
                    .catch(function (reason){});
            }

        },
        mounted:function (){
            this.getCart();
        }

    });
}