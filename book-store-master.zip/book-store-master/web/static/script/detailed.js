window.onload=function (){
    var vue = new Vue({
        el:"#cart_div",
        data:{
            orderList:{}
        },
        methods:{
            getOrder:function (){
                axios({
                    method:"POST",
                    url:"order.do",
                    params:{
                        operate:'detailMess'
                    }
                })
                    .then(function (value){
                        var orderList = value.data;
                        vue.orderList = orderList;
                    })
                    .catch(function (reason){ });
            }
        },
        mounted:function (){
            this.getOrder();
        }

    });
}