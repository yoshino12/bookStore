function $(id){
    return document.getElementById(id);
}
function addCart(bookId) {
    window.location.href = 'cart.do?operate=addCart&bookId=' + bookId;
}

window.onload = function () {
    $("newMes").style.color = 'red';
    var vue = new Vue({
        el: "#index_div",
        data: {
            bookList: {},
            cart:{},
            pageNo:"1",
            pageCount :"",
            bookCount:"",
            turnPageNO:"1",//想要跳转的页数
            keyword : "",
            oper : ""
        },
        methods: {
            getBookList: function () {
                axios({
                    method: "POST",
                    url: "book.do",
                    params: {
                        operate: 'getBookList',
                        pageNo: vue.pageNo,
                        keyword : vue.keyword,
                        oper : vue.oper
                    }
                })
                    .then(function (value) {
                        var bookList = value.data;
                        vue.bookList = bookList;
                    })
                    .catch(function (reason) {});
            },
            addCart: function (bookId) {
                axios({
                    url: "cart.do",
                    params: {
                        operate: 'addCart',
                        bookId: bookId
                    }
                })
                    .then(function (value){
                        vue.getBookList();
                        var mess = value.data;
                        alert(mess + '!');

                    })
                    .catch(function (reason){})
            },
            page:function (num){
                vue.pageNo = Number(vue.pageNo) + Number(num);
                vue.getBookList();
            },
            firstPage:function (){
                vue.pageNo = 1;
                vue.getBookList();
            },
            lastPage:function (){
                vue.pageNo = vue.pageCount;
                vue.getBookList();
            },
            turnPage: function (){
                var no = vue.turnPageNo;
                if (Number(no) < 0){
                    vue.firstPage();
                    vue.turnPageNo = 1;
                }else if (Number(no) > Number(vue.pageCount)){
                    vue.lastPage();
                    vue.turnPageNo = vue.pageCount;
                }else {
                    vue.pageNo = no;
                    vue.getBookList();
                }
            },
            getPageCount:function (){
                axios({
                    url: "book.do",
                    params: {
                        operate: 'getPageCount',
                        keyword : vue.keyword
                    }
                })
                    .then(function (value){
                        vue.pageCount = value.data;
                        vue.getBookCount();
                    })
            },
            getBookCount:function (){
                axios({
                    url: "book.do",
                    params: {
                        operate: 'getBookCount',
                        keyword : vue.keyword
                    }
                })
                    .then(function (value){
                        vue.bookCount = value.data;
                    })
            },
            searchKeyword:function () {
                vue.oper = "search";
                vue.pageNo = 1;
                vue.getBookList();
                vue.getPageCount();
                vue.oper = "";
            },
            restartKeyword:function (){
                vue.oper = "search";
                vue.pageNo = 1;
                vue.keyword = "";
                vue.getBookList();
                vue.getPageCount();
                vue.oper = "";
            }

        }
    });

    vue.getBookList();
    vue.getPageCount();

}



function hotBookApp(){
    //将页面显示为热销榜单
    var hotBookStyle = $("hotBook");
    var newBookStyle = $("newBook");
    var goodBookStyle = $("goodBook");
    goodBookStyle.style.display = "none";
    newBookStyle.style.display = "none";
    hotBookStyle.style.display = "block";
    $("hotMes").style.color = 'red';
    $("goodMes").style.color = '#39987c';
    $("newMes").style.color = '#39987c';
}

function goodBookApp(){
    //将页面显示为推荐榜单
    var goodBookStyle = $("goodBook");
    var newBookStyle = $("newBook");
    var hotBookStyle = $("hotBook");
    hotBookStyle.style.display = "none";
    newBookStyle.style.display = "none";
    goodBookStyle.style.display = "block";
    $("goodMes").style.color = 'red';
    $("hotMes").style.color = '#39987c';
    $("newMes").style.color = '#39987c';
}

function newBookApp(){
    //将页面显示为新书榜单
    var goodBookStyle = $("goodBook");
    var newBookStyle = $("newBook");
    var hotBookStyle = $("hotBook");
    hotBookStyle.style.display = "none";
    goodBookStyle.style.display = "none";
    newBookStyle.style.display = "block";
    $("newMes").style.color = 'red';
    $("hotMes").style.color = '#39987c';
    $("goodMes").style.color = '#39987c';
}