package com.yoshino.book.service.impl;

import com.yoshino.book.dao.BookDAO;
import com.yoshino.book.pojo.Book;
import com.yoshino.book.service.BookService;

import java.util.List;

public class BookServiceImpl implements BookService {

    private BookDAO bookDAO;

    @Override
    public List<Book> getBookList() {
        return bookDAO.getBookList();
    }

    @Override
    public Book getBook(Integer id) {
        return bookDAO.getBook(id);
    }

    @Override
    public List<Book> getBookStatusList() {
        return bookDAO.getBookStatusList();
    }

    @Override
    public Book getBookStatus(Integer id) {
        return bookDAO.getBookStatus(id);
    }

    @Override
    public void updateBookStatus(Book book) {
        bookDAO.updateBookStatus(book);
    }

    @Override
    public void addBookStatus(Book book) {
        bookDAO.addBookStatus(book);
    }

    @Override
    public void delBookStatus(Integer id) {
        bookDAO.delBookStatus(id);
    }

    @Override
    public List<Book> getBookList(String keyword, Integer pageNo) {
        return bookDAO.getBookList(keyword,pageNo);
    }

    @Override
    public Integer getPageCount(String keyword) {
        int bookCount = bookDAO.getBookCount(keyword);
        if (bookCount == 0){
            return 0;
        }
        //总页数
        int pageCount = (bookCount + 10 - 1) / 10;
        return pageCount;
    }

    @Override
    public Integer getBookCount(String keyword) {
        return bookDAO.getBookCount(keyword);
    }

    @Override
    public void updateBook(Book book) {
        bookDAO.updateBook(book);
    }

    @Override
    public void editBook(Book book) {
        bookDAO.editBook(book);
    }
}
