package com.yoshino.book.service;

import com.yoshino.book.pojo.Book;

import java.util.List;

public interface BookService {
    List<Book> getBookList();
    Book getBook(Integer id);
    List<Book> getBookStatusList();
    //获得指定图书的特殊状态（1：新上架，2：热销，3：推荐）
    Book getBookStatus(Integer id);
    //修改图书状态
    void updateBookStatus(Book book);
    //添加图书状态
    void addBookStatus(Book book);
    //删除图书状态
    void delBookStatus(Integer id);
    //获取指定页码上的书籍列表信息，
    List<Book> getBookList(String keyword, Integer pageNo);
    //获取指定查询信息的书籍总页数
    Integer getPageCount(String keyword);
    //获取指定查询信息的书籍总数
    Integer getBookCount(String keyword);
    //修改指定书的信息(用于结账后更新
    void updateBook(Book book);
    //修改指定书的信息(管理员权限
    void editBook(Book book);
}
