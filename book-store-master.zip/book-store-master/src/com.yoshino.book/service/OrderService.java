package com.yoshino.book.service;

import com.yoshino.book.pojo.OrderBean;
import com.yoshino.book.pojo.User;

import java.util.List;

public interface OrderService {
    //
    void addOrderBean(OrderBean orderBean);
    List<OrderBean> getOrderList(User user);
    List<OrderBean> getOrderListByManager();
    void changeStatus(String orderNo, Integer orderStatus);
    //根据订单id获取特定的订单项
    OrderBean getOrderBean(Integer id);
}
