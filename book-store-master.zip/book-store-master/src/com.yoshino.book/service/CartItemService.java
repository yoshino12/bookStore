package com.yoshino.book.service;

import com.yoshino.book.pojo.Cart;
import com.yoshino.book.pojo.CartItem;
import com.yoshino.book.pojo.User;

import java.util.List;

public interface CartItemService {
    void addCartItem(CartItem cartItem);
    void updateCartItem(CartItem cartItem);
    void addOrupdateCartItem(CartItem cartItem, Cart cart);

    //获取指定用户的所有购物车项列表（需要注意：这个方法内存查询的时候，会将book的详细信息记录
    List<CartItem> getCartItemList(User user);

    //加载特定用户的购物车信息
    Cart getCart(User user);

    //删除特定购物车项
    void delCart(CartItem cartItem);
}
