package com.yoshino.book.controller;

import com.google.gson.Gson;
import com.yoshino.book.pojo.Book;
import com.yoshino.book.service.BookService;
import com.yoshino.myssm.util.StringUtil;

import javax.servlet.http.HttpSession;
import java.util.List;

public class BookController {

    private BookService bookService;

    public String index(HttpSession session) {
        //图书列表
//        List<Book> bookList = bookService.getBookList();
        //图书状态列表
        List<Book> bookStatusList = bookService.getBookStatusList();
//        session.setAttribute("bookList", bookList);
        session.setAttribute("bookStatusList", bookStatusList);
        return "index";
    }

    public String editBook(Integer bookId, String name, Double price, String author, Integer saleCount, Integer bookCount, Integer bookStatus, HttpSession session) {

        Book bookStatus1 = bookService.getBookStatus(bookId);
        if (bookStatus1 == null) {
            if (bookStatus != 0){
                bookService.addBookStatus(new Book(bookId, bookStatus));
            }
        } else {
            if (bookStatus != 0){
                bookService.updateBookStatus(new Book(bookId, bookStatus));
            }else {
                bookService.delBookStatus(bookId);
            }
        }

        bookService.editBook(new Book(bookId, name, price, author, saleCount, bookCount));
        return "redirect:manager.do";
    }


    public String getBookList(String oper, String keyword, Integer pageNo, HttpSession session) {
        if (pageNo == null) {
            pageNo = 1;
        }
        //模糊查询进入的
        if (StringUtil.isNotEmpty(oper) && "search".equals(oper)) {
            pageNo = 1;
            //直接点查询，无查询关键字
            if (StringUtil.isEmpty(keyword)) {
                keyword = "";
            }
            session.setAttribute("keyword", keyword);
        } else {
            Object keywordObj = session.getAttribute("keyword");
            if (keywordObj != null) {
                keyword = (String) keywordObj;
            } else {
                keyword = "";
            }
        }

        //总页数
        int pageCount = bookService.getPageCount(keyword);
        if (pageCount == 0){
            return "json:";
        }
        session.setAttribute("pageCount", pageCount);

        //判断该页是否违规
        if (pageNo < 1) {
            pageNo = 1;
        } else if (pageNo > pageCount) {
            pageNo = pageCount;
        }

        //重新更新当前页的值
        session.setAttribute("pageNo", pageNo);
        List<Book> bookList = bookService.getBookList(keyword, pageNo);
        Gson gson = new Gson();
        String bookListJson = gson.toJson(bookList);
        return "json:" + bookListJson;


    }

   /* public String getBookStatusList(HttpSession session) {
        List<Book> bookStatusListList = bookService.getBookStatusList();
        Gson gson = new Gson();
        String bookStatusListJsonStr = gson.toJson(bookStatusListList);
        return "json:" + bookStatusListJsonStr;
    }*/

    public String getPageCount(String keyword) {
        if (StringUtil.isEmpty(keyword)) {
            keyword = "";
        }
        //总页数
        int pageCount = bookService.getPageCount(keyword);
        Gson gson = new Gson();
        String json = gson.toJson(pageCount);
        return "json:" + json;
    }

    public String getBookCount(String keyword) {
        if (StringUtil.isEmpty(keyword)) {
            keyword = "";
        }
        //总页数
        int bookCount = bookService.getBookCount(keyword);
        Gson gson = new Gson();
        String json = gson.toJson(bookCount);
        return "json:" + json;
    }
}
