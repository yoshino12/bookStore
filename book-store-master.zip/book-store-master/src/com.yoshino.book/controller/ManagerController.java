package com.yoshino.book.controller;

import com.google.gson.Gson;
import com.yoshino.book.pojo.Book;
import com.yoshino.book.pojo.OrderBean;
import com.yoshino.book.service.BookService;
import com.yoshino.book.service.OrderService;

import javax.servlet.http.HttpSession;
import java.util.List;

public class ManagerController {

    private BookService bookService;
    private OrderService orderService;

    public String index(HttpSession session) {
        List<Book> bookList = bookService.getBookList();
        for (Book book : bookList) {
            Book bookStatus = bookService.getBookStatus(book.getId());
            if (bookStatus != null) {
                book.setBookStatus(bookStatus.getBookStatus());
            }
        }
        session.setAttribute("bookList", bookList);
        return "manager/book_manager";
    }

    public String editPage(Integer bookId, HttpSession session) {
        Book book = bookService.getBook(bookId);
        Book bookStatus = bookService.getBookStatus(bookId);
        if (bookStatus != null) {
            book.setBookStatus(bookStatus.getBookStatus());
        }
        //默认为0
        session.setAttribute("book", book);
        return "manager/book_edit";
    }

    public String orderIndex(HttpSession session){
        List<OrderBean> orderListByManager = orderService.getOrderListByManager();
        Gson gson = new Gson();
        String json = gson.toJson(orderListByManager);

        return "json:" + json;
    }

    //修改订单状态（用户
    public String changeStatus(HttpSession session,String orderNo){
        orderService.changeStatus(orderNo,1);
        return "";
    }
}
