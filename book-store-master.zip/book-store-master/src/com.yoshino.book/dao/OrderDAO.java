package com.yoshino.book.dao;

import com.yoshino.book.pojo.OrderBean;
import com.yoshino.book.pojo.User;

import java.util.List;

public interface OrderDAO {
    //添加订单
    void addOrderBean(OrderBean orderBean);
    //获取指定用户的订单列表
    List<OrderBean> getOrderList(User user);



    Integer getOrderTotalBookCount(OrderBean orderBean);

    //获取所有用户的订单表
    List<OrderBean> getOrderListByManager();

    //改变订单状态
    void changeStatus(String orderNo, Integer orderStatus);

    //根据订单id获取特定的订单项
    OrderBean getOrderBean(Integer id);
}
