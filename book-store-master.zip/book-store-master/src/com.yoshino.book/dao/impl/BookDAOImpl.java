package com.yoshino.book.dao.impl;

import com.yoshino.book.dao.BookDAO;
import com.yoshino.book.pojo.Book;
import com.yoshino.myssm.basedao.DAO;

import java.util.List;

public class BookDAOImpl extends DAO<Book> implements BookDAO {
    @Override
    public List<Book> getBookList() {
        return executeQuery("select * from t_book");
    }

    @Override
    public Book getBook(Integer id) {
        return load("select * from t_book where id = ?", id);
    }

    @Override
    public List<Book> getBookStatusList() {
        return executeQuery("select tb.id as id, bookImg, bookName, price, bookStatus from t_book_status tbs left join t_book tb on tb.id = tbs.book;");
    }

    @Override
    public Book getBookStatus(Integer id) {
        return load("select bookStatus, book as id from t_book_status where book = ?",id);
    }

    @Override
    public void updateBookStatus(Book book) {
        executeUpdate("update t_book_status set bookStatus = ? where book = ?",book.getBookStatus(),book.getId());
    }

    @Override
    public void addBookStatus(Book book) {
        executeUpdate("insert into t_book_status values(0,?,?)",book.getId(),book.getBookStatus());
    }

    @Override
    public void delBookStatus(Integer id) {
        executeUpdate("delete from t_book_status where book = ?",id);
    }

    @Override
    public List<Book> getBookList(String keyword, Integer pageNo) {
        return executeQuery("select * from t_book where bookName like ? limit ?, 10","%" + keyword + "%", (pageNo - 1) * 10);
    }

    @Override
    public int getBookCount(String keyword) {
        return ((Long)super.executeComplexQuery("select count(*) from t_book where bookName like ? " ,"%" + keyword + "%")[0]).intValue();
    }

    @Override
    public void updateBook(Book book) {
        executeUpdate("update t_book set saleCount = ?, bookCount = ? where id = ?",book.getSaleCount(), book.getBookCount(), book.getId());
    }

    @Override
    public void editBook(Book book) {
        executeUpdate("update t_book set bookName = ?, price = ?, author = ?, saleCount = ?, bookCount = ? where id = ?",book.getBookName(),book.getPrice(),book.getAuthor(),book.getSaleCount(),book.getBookCount(),book.getId());
    }
}
