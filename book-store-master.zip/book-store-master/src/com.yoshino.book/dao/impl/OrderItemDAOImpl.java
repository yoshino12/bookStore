package com.yoshino.book.dao.impl;

import com.yoshino.book.dao.OrderItemDAO;
import com.yoshino.book.pojo.OrderItem;
import com.yoshino.myssm.basedao.DAO;

import java.util.List;

public class OrderItemDAOImpl extends DAO<OrderItem> implements OrderItemDAO {
    @Override
    public void addOrderItem(OrderItem orderItem) {
        super.executeUpdate("insert into t_order_item values(0,?,?,?)",orderItem.getBook().getId(),orderItem.getBuyCount(),orderItem.getOrderBean().getId());
    }
    @Override
    public List<OrderItem> getOrderList(Integer id) {
        return executeQuery("select * from t_order_item where orderBean = ? ",id);
    }
}
