package com.yoshino.book.dao;

import com.yoshino.book.pojo.OrderItem;

import java.util.List;

public interface OrderItemDAO {
    //添加订单项
    void addOrderItem(OrderItem orderItem);
    //获取指定用户的订单列表
    List<OrderItem> getOrderList(Integer id);
}
