package com.yoshino.book.dao;

import com.yoshino.book.pojo.Book;

import java.util.List;

public interface BookDAO {
    //List<Book> getBookList(Integer minPrice, Integer maxPrice, Integer pageNo);
    List<Book> getBookList();
    Book getBook(Integer id);
    //获得特殊状态的图书列表（1：新上架，2：热销，3：推荐）
    List<Book> getBookStatusList();
    //获得指定图书的特殊状态（1：新上架，2：热销，3：推荐）
    Book getBookStatus(Integer id);
    //修改图书状态
    void updateBookStatus(Book book);
    //添加图书状态
    void addBookStatus(Book book);
    //删除图书状态
    void delBookStatus(Integer id);
    //获取指定页码上的书籍列表信息，
    List<Book> getBookList(String keyword, Integer pageNo);
    //获取指定查询信息的书籍总数
    int getBookCount(String keyword);
    //修改图书信息(销量，库存
    void updateBook(Book book);
    //修改图书信息（管理员
    void editBook(Book book);
}
