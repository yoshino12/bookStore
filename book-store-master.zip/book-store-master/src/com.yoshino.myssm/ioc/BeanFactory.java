package com.yoshino.myssm.ioc;

public interface BeanFactory {
    //
    Object getBean(String id);
}
