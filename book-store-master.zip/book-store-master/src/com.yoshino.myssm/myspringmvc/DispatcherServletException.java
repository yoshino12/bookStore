package com.yoshino.myssm.myspringmvc;

public class DispatcherServletException extends RuntimeException{
    public DispatcherServletException(String msg){
        super(msg);
    }
}
